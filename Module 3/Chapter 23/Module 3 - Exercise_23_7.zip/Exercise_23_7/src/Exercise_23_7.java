/**
 * @author Chandelor
 * Date: 12/6/2023
 */
public class Exercise_23_7 {

	@SuppressWarnings("unchecked")
	public static <E extends Comparable<E>> void main(String[] args) {

		Integer[] list = {-44, -5, -3, 3, 3, 1, -4, 0, 1, 2, 4, 5, 53};
		Heap<E> heap = new Heap<E>();
		
		for (int n = 0; n < list.length; n++) heap.add((E) list[n]);
		
		heap.print();
	}

}