/**
 * @author Chandelor
 * Date: 12/5/2023
 */
import java.util.Comparator;

public class Exercise_23_3 {
	
	public static void main(String[] args) {
		Integer[] list = {2, 3, 2, 5, 6, 1, -2, 3, 14, 12};
		quickSort(list);
		
		for (int i = 0; i < list.length; i++) {
			System.out.print(list[i] + " ");
		}
		
		System.out.println();
		Circle[] list1 = {new Circle(2), new Circle(3), new Circle(2),
						  new Circle(5), new Circle(6), new Circle(1), new Circle(2),
						  new Circle(3), new Circle(14), new Circle(12)};
		
		quickSortObject(list1, new GeometricObjectComparator());
		
		for (int i = 0; i < list1.length; i++) {
			System.out.println(list1[i] + " ");
		}
		
	}
	
	public static <E extends Comparable<E>> void quickSort(E[] list) {
		quickSort(list, 0, list.length - 1);
	}
	
	public static <E extends Comparable<E>> void quickSort(E[] list, int start, int end) {
		if (end > start) {
			int pivot = comparableSplitList(list, start, end);
			quickSort(list, start, pivot -  1);
			quickSort(list, pivot + 1, end);
		}
		
	}

	public static <E extends Comparable<E>> int comparableSplitList(E[] list, int start, int end) {
		int frontIndex = start + 1;
		int backIndex = end;
		E pivot = list[start];

		while (backIndex > frontIndex) {
			while (frontIndex <= backIndex && list[frontIndex].compareTo(pivot) <= 0) frontIndex++;
			while (frontIndex <= backIndex && list[backIndex].compareTo(pivot) > 0) backIndex--;
				
			if (backIndex > frontIndex) {
				E temp = list[backIndex];
				list[backIndex] = list[frontIndex];
				list[frontIndex] = temp;
			}
			
		}

		while (backIndex > start && list[backIndex].compareTo(pivot) >= 0) backIndex--;
		
		if (pivot.compareTo(list[backIndex]) > 0) {
			list[start] = list[backIndex];
			list[backIndex] = pivot;
			return backIndex;
		}
		
		else return start;
	}
	
	public static <E> void quickSortObject(E[] list, Comparator<? super E> comparator) {
		quickSortObject(list, comparator, 0, list.length - 1);
	}

	public static <E> void quickSortObject(E[] list, Comparator<? super E> comparator, int start, int end) {
		if (end > start) {
			int pivot = comparatorSplitList(list, comparator, start, end);
			quickSortObject(list, comparator, start, pivot - 1);
			quickSortObject(list, comparator, pivot + 1, end);
		}
		
	}

	public static <E> int comparatorSplitList(E[] list, Comparator<? super E> comparator, int start, int end) {
		int frontIndex = start + 1;
		int backIndex = end;
		E pivot = list[start];

		while (backIndex > frontIndex) {
			while (frontIndex <= backIndex && comparator.compare(list[frontIndex], pivot) <= 0) frontIndex++;
			while (frontIndex <= backIndex && comparator.compare(list[backIndex], pivot) > 0) backIndex--;
				
			if (backIndex > frontIndex) {
				E temp = list[backIndex];
				list[backIndex] = list[frontIndex];
				list[frontIndex] = temp;
			}
			
		}

		while (backIndex > start && comparator.compare(list[backIndex], pivot) >= 0) backIndex--;
		
		if (comparator.compare(pivot, list[backIndex]) > 0) {
			list[start] = list[backIndex];
			list[backIndex] = pivot;
			return backIndex;
		}
		
		else return start;
	}

}
